#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(caret)
library(ggplot2)
library(ClusterR)
library(mclust)
library(cluster)

# Define UI for application that draws a histogram
ui <- fluidPage(
    fileInput("f", "Upload CSV File with Data",
              accept = c(
                  "text/csv",
                  "text/comma-separated-values,text/plain",
                  ".csv")
              
    ),
    helpText("Click either of the following buttons"),
    actionButton("b2","2 clusters"),
    actionButton("b3","3clusters"),
    actionButton("b4","4 clusters"),
    helpText("Adjust Slider for iteration"),

    sliderInput("obs", "Iteration",
                min = 1, max = 10, value =1
    ),
     textOutput("topt"),
    plotOutput("g3"),
    tableOutput("tb")
    
    
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    
    r2=reactive({ validate(
        need(input$f != "", "")
        
    )
        f1=input$f
        f2=read.csv(f1$datapath)
        
        vrp=as.data.frame(f2)
        
        
        vrp=vrp[1:15,1:5]
        
        
        dummy <- dummyVars(" ~ .", data=vrp)
        vrp1 <- data.frame(predict(dummy, newdata = vrp)) 
        
        vrp1=vrp1[,-c(5)]
        vrp1$task=vrp$task
        vrp1$taskid=as.factor(vrp1$taskid)
        vrp
    })
    
    
    
    
    
    
r4=reactive({
    obs=input$obs
    obs
})



    observeEvent(input$b2,{
    l=list()
    vrp1=r2()
    
    
    
    set.seed(10)
    for(i in 1:10)
        
    {   d=daisy(vrp1[,-c(1)])
        h=hclust(d,method ="average")
        ct1=cutree(h,k=2)
        vrp1$cluster2=as.factor(ct1)
    l=append(l,data.frame(vrp1))
    
   
    x_j=vrp1$x[12]
    y_j=vrp1$y[12]
    x_j1=vrp1$x[13]
    y_j1=vrp1$y[13]
    vrp1$x[12]=round(runif(1,x_j-5,x_j+5))
    vrp1$y[12]=round(runif(1,y_j-5,y_j+5))
    vrp1$x[13]=round(runif(1,x_j1-5,x_j1+5))
    vrp1$y[13]=round(runif(1,y_j1-5,y_j1+5))
    
    }
    
    output$topt=renderText({
        "Results for 2 clusters"
    })
    output$g3=renderPlot({
        obs=r4()
        df1=as.data.frame(l[((6*obs)-5):(6*obs)])
        ggplot(df1)+geom_point(mapping=aes(x,y,color=cluster2,shape=task),size=5)+geom_label(mapping=aes(x=x,y=y,label=taskid),nudge_x =1.2,nudge_y =1.2 )
    })
    
    output$tb=renderTable({
        obs=r4()
        m=as.data.frame(l[((6*obs)-5):(6*obs)])
        
        m[,c(1,2,3,5)]
    })
    })
    observeEvent(input$b3,{
        
        
        
        m=list()
        vrp1=r2()
        set.seed(10)
        for(i in 1:10)
        {  d=daisy(vrp1[,-c(1)])
         h=hclust(d,method ="average")
            ct1=cutree(h,k=3)
        vrp1$cluster3=as.factor(ct1)
        m=append(m,data.frame(vrp1))
        
        
       
            x_j=vrp1$x[12]
            y_j=vrp1$y[12]
            x_j1=vrp1$x[13]
            y_j1=vrp1$y[13]
            vrp1$x[12]=round(runif(1,x_j-5,x_j+5))
            vrp1$y[12]=round(runif(1,y_j-5,y_j+5))
            vrp1$x[13]=round(runif(1,x_j1-5,x_j1+5))
            vrp1$y[13]=round(runif(1,y_j1-5,y_j1+5))
        
        
        }
        output$topt=renderText({
            "Results for 3 clusters"
        })
        output$g3=renderPlot({
            obs=r4()
            df1=as.data.frame(m[((6*obs)-5):(6*obs)])
            ggplot(df1)+geom_point(mapping=aes(x,y,color=cluster3,shape=task),size=5)+geom_label(mapping=aes(x=x,y=y,label=taskid),nudge_x =1.2,nudge_y =1.2 )
        })
        output$tb=renderTable({
            obs=r4()
            m=as.data.frame(m[((6*obs)-5):(6*obs)])
            
           m[,c(1,2,3,9)]
        })
    })
           
    observeEvent(input$b4,{
        n=list()
        vrp1=r2()
        
       
       
        set.seed(10)
        for(i in 1:10)
        { d=daisy(vrp1[,-c(1)])
        h=hclust(d)
        ct1=cutree(h,k=4)
        vrp1$cluster4=as.factor(ct1)
        n=append(n,data.frame(vrp1))
        
        
        x_j=vrp1$x[12]
        y_j=vrp1$y[12]
        x_j1=vrp1$x[13]
        y_j1=vrp1$y[13]
        vrp1$x[12]=round(runif(1,x_j-5,x_j+5))
        vrp1$y[12]=round(runif(1,y_j-5,y_j+5))
        vrp1$x[13]=round(runif(1,x_j1-5,x_j1+5))
        vrp1$y[13]=round(runif(1,y_j1-5,y_j1+5))
        
        }
        output$topt=renderText({
            "Results for 4 clusters"
        })
        output$g3=renderPlot({
            obs=r4()
            df1=as.data.frame(n[((6*obs)-5):(6*obs)])
            ggplot(df1)+geom_point(mapping=aes(x,y,color=cluster4,shape=task),size=5)+geom_label(mapping=aes(x=x,y=y,label=taskid),nudge_x =1.2,nudge_y =1.2 )
        })
        output$tb=renderTable({
            obs=r4()
            m=as.data.frame(n[((6*obs)-5):(6*obs)])
            
            m[,c(1,2,3,5)]
        })
    })
    
    
        
    
    output$g3=renderPlot({
        
        vrp1=r2()
        ggplot(vrp1)+geom_point(mapping=aes(x,y,color=task,size=energy))+geom_label(mapping=aes(x=x,y=y,label=taskid),nudge_x =1.2,nudge_y =1.2 )
    })
    
    
       
        
   
    output$topt=renderText({
        "general data viz"
    })
    
   

    
}

# Run the application 
shinyApp(ui = ui, server = server)
